import { createFileRoute } from "@tanstack/react-router";
import type {} from "@tanstack/react-start";

const BASE_URL = "https://ourblast.xyz";

interface SitemapEntry {
  path: string;
  changefreq?: "always" | "hourly" | "daily" | "weekly" | "monthly" | "yearly" | "never";
  priority?: string;
}

const entries: SitemapEntry[] = [
  { path: "/", changefreq: "weekly", priority: "1.0" },
  { path: "/hub", changefreq: "daily", priority: "0.9" },
  { path: "/build", changefreq: "weekly", priority: "0.9" },
  { path: "/builders", changefreq: "daily", priority: "0.8" },
  { path: "/ecosystem", changefreq: "daily", priority: "0.8" },
  { path: "/community-city", changefreq: "daily", priority: "0.8" },
  { path: "/arcade", changefreq: "daily", priority: "0.9" },
  { path: "/how-to-play", changefreq: "monthly", priority: "0.8" },
  { path: "/leaderboard", changefreq: "hourly", priority: "0.8" },
  { path: "/meme", changefreq: "daily", priority: "0.6" },
  { path: "/roast", changefreq: "weekly", priority: "0.6" },
  { path: "/chat", changefreq: "hourly", priority: "0.5" },
  { path: "/terms", changefreq: "yearly", priority: "0.4" },
  { path: "/privacy", changefreq: "yearly", priority: "0.4" },
];

export const Route = createFileRoute("/sitemap.xml")({
  server: {
    handlers: {
      GET: async () => {
        const urls = entries.map((e) =>
          [
            `  <url>`,
            `    <loc>${BASE_URL}${e.path}</loc>`,
            e.changefreq ? `    <changefreq>${e.changefreq}</changefreq>` : null,
            e.priority ? `    <priority>${e.priority}</priority>` : null,
            `  </url>`,
          ]
            .filter(Boolean)
            .join("\n"),
        );

        const xml = [
          `<?xml version="1.0" encoding="UTF-8"?>`,
          `<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">`,
          ...urls,
          `</urlset>`,
        ].join("\n");

        return new Response(xml, {
          headers: {
            "Content-Type": "application/xml",
            "Cache-Control": "public, max-age=3600",
          },
        });
      },
    },
  },
});
