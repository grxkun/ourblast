// SPDX-License-Identifier: BUSL-1.1
/**
 * Minimal X API v2 client using OAuth 1.0a user-context signing, so @ourblastbot can
 * read its mentions and post replies. Server-only: credentials are read from env here.
 */
import { enforceSingleCashtag } from "./x-bot";

const API = "https://api.x.com";

export interface XCredentials {
  apiKey: string;
  apiSecret: string;
  accessToken: string;
  accessSecret: string;
}

export function readXCredentials(): XCredentials | null {
  const apiKey = process.env["X_BOT_API_KEY"];
  const apiSecret = process.env["X_BOT_API_SECRET"];
  const accessToken = process.env["X_BOT_ACCESS_TOKEN"];
  const accessSecret = process.env["X_BOT_ACCESS_SECRET"];
  if (!apiKey || !apiSecret || !accessToken || !accessSecret) return null;
  return { apiKey, apiSecret, accessToken, accessSecret };
}

const rfc3986 = (value: string) =>
  encodeURIComponent(value).replace(/[!'()*]/g, (char) => `%${char.charCodeAt(0).toString(16).toUpperCase()}`);

async function hmacSha1(key: string, message: string): Promise<string> {
  const cryptoKey = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(key),
    { name: "HMAC", hash: "SHA-1" },
    false,
    ["sign"],
  );
  const signature = await crypto.subtle.sign("HMAC", cryptoKey, new TextEncoder().encode(message));
  return btoa(String.fromCharCode(...new Uint8Array(signature)));
}

async function authorizationHeader(
  credentials: XCredentials,
  method: "GET" | "POST",
  url: string,
  queryParams: Record<string, string>,
): Promise<string> {
  const oauth: Record<string, string> = {
    oauth_consumer_key: credentials.apiKey,
    oauth_nonce: crypto.randomUUID().replace(/-/g, ""),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: Math.floor(Date.now() / 1000).toString(),
    oauth_token: credentials.accessToken,
    oauth_version: "1.0",
  };

  // JSON request bodies are not part of the OAuth 1.0a signature base string.
  const all = { ...oauth, ...queryParams };
  const parameterString = Object.keys(all)
    .sort()
    .map((key) => `${rfc3986(key)}=${rfc3986(all[key] as string)}`)
    .join("&");

  const base = [method, rfc3986(url), rfc3986(parameterString)].join("&");
  const signingKey = `${rfc3986(credentials.apiSecret)}&${rfc3986(credentials.accessSecret)}`;
  oauth["oauth_signature"] = await hmacSha1(signingKey, base);

  return `OAuth ${Object.keys(oauth)
    .sort()
    .map((key) => `${rfc3986(key)}="${rfc3986(oauth[key] as string)}"`)
    .join(", ")}`;
}

async function request<T>(
  credentials: XCredentials,
  method: "GET" | "POST",
  path: string,
  options: { query?: Record<string, string>; body?: unknown } = {},
): Promise<T> {
  const url = `${API}${path}`;
  const query = options.query ?? {};
  const header = await authorizationHeader(credentials, method, url, query);
  const search = new URLSearchParams(query).toString();

  const response = await fetch(search ? `${url}?${search}` : url, {
    method,
    headers: {
      authorization: header,
      ...(options.body ? { "content-type": "application/json" } : {}),
    },
    ...(options.body ? { body: JSON.stringify(options.body) } : {}),
  });

  if (!response.ok) {
    const detail = await response.text();
    console.error(`X API ${method} ${path} failed [${response.status}]: ${detail}`);
    throw new Error(`X API ${method} ${path} failed [${response.status}]: ${detail.slice(0, 400)}`);
  }
  return (await response.json()) as T;
}

/** The authenticated bot account. */
export async function getBotAccount(credentials: XCredentials) {
  const result = await request<{ data: { id: string; username: string; name: string } }>(
    credentials,
    "GET",
    "/2/users/me",
  );
  return result.data;
}

export interface XMentionItem {
  id: string;
  text: string;
  author_id?: string;
  username?: string;
  /** First picture attached to the tweet, used as the token image. */
  imageUrl?: string | null;
}

/** Mentions of the bot, newest last, restricted to anything after `sinceId`. */
export async function listMentions(credentials: XCredentials, botUserId: string, sinceId?: string | null) {
  const query: Record<string, string> = {
    max_results: "25",
    "tweet.fields": "author_id,created_at,attachments",
    expansions: "author_id,attachments.media_keys",
    "user.fields": "username",
    "media.fields": "url,preview_image_url,type",
  };
  if (sinceId) query["since_id"] = sinceId;

  const result = await request<{
    data?: Array<{ id: string; text: string; author_id?: string; attachments?: { media_keys?: string[] } }>;
    includes?: {
      users?: Array<{ id: string; username: string }>;
      media?: Array<{ media_key: string; url?: string; preview_image_url?: string; type?: string }>;
    };
  }>(credentials, "GET", `/2/users/${botUserId}/mentions`, { query });

  const users = new Map((result.includes?.users ?? []).map((user) => [user.id, user.username]));
  const media = new Map(
    (result.includes?.media ?? []).map((item) => [item.media_key, item.url ?? item.preview_image_url ?? null]),
  );
  return (result.data ?? [])
    .map((tweet): XMentionItem => {
      const key = tweet.attachments?.media_keys?.find((mediaKey) => media.get(mediaKey));
      return {
        id: tweet.id,
        text: tweet.text,
        imageUrl: key ? media.get(key) ?? null : null,
        ...(tweet.author_id ? { author_id: tweet.author_id, username: users.get(tweet.author_id) ?? "" } : {}),
      };
    })
    .reverse();
}

/**
 * Recent search for tweets mentioning the bot. The mentions timeline sometimes stalls
 * or skips tweets, so this is used as a second source; results are newest last.
 */
export async function searchMentions(credentials: XCredentials, handle: string, sinceId?: string | null) {
  const query: Record<string, string> = {
    query: `@${handle.replace(/^@/, "")} -is:retweet`,
    max_results: "25",
    "tweet.fields": "author_id,created_at,attachments",
    expansions: "author_id,attachments.media_keys",
    "user.fields": "username",
    "media.fields": "url,preview_image_url,type",
  };
  if (sinceId) query["since_id"] = sinceId;

  const result = await request<{
    data?: Array<{ id: string; text: string; author_id?: string; attachments?: { media_keys?: string[] } }>;
    includes?: {
      users?: Array<{ id: string; username: string }>;
      media?: Array<{ media_key: string; url?: string; preview_image_url?: string; type?: string }>;
    };
  }>(credentials, "GET", "/2/tweets/search/recent", { query });

  const users = new Map((result.includes?.users ?? []).map((user) => [user.id, user.username]));
  const media = new Map(
    (result.includes?.media ?? []).map((item) => [item.media_key, item.url ?? item.preview_image_url ?? null]),
  );
  return (result.data ?? [])
    .map((tweet): XMentionItem => {
      const key = tweet.attachments?.media_keys?.find((mediaKey) => media.get(mediaKey));
      return {
        id: tweet.id,
        text: tweet.text,
        imageUrl: key ? media.get(key) ?? null : null,
        ...(tweet.author_id ? { author_id: tweet.author_id, username: users.get(tweet.author_id) ?? "" } : {}),
      };
    })
    .reverse();
}

/** The first picture attached to one tweet, read on demand. */
export async function fetchTweetImage(credentials: XCredentials, postId: string): Promise<string | null> {
  const result = await request<{
    data?: { attachments?: { media_keys?: string[] } };
    includes?: { media?: Array<{ media_key: string; url?: string; preview_image_url?: string }> };
  }>(credentials, "GET", `/2/tweets/${postId}`, {
    query: { "tweet.fields": "attachments", expansions: "attachments.media_keys", "media.fields": "url,preview_image_url,type" },
  }).catch(() => null);
  const item = (result?.includes?.media ?? [])[0];
  return item?.url ?? item?.preview_image_url ?? null;
}

/** Full tweet details (text, author username, first picture), read on demand. */
export async function fetchTweetDetails(credentials: XCredentials, postId: string): Promise<XMentionItem | null> {
  const result = await request<{
    data?: { id: string; text: string; author_id?: string; attachments?: { media_keys?: string[] } };
    includes?: {
      users?: Array<{ id: string; username: string }>;
      media?: Array<{ media_key: string; url?: string; preview_image_url?: string }>;
    };
  }>(credentials, "GET", `/2/tweets/${postId}`, {
    query: {
      "tweet.fields": "author_id,attachments",
      expansions: "author_id,attachments.media_keys",
      "user.fields": "username",
      "media.fields": "url,preview_image_url,type",
    },
  }).catch((error) => {
    console.error(`fetchTweetDetails ${postId} failed: ${error instanceof Error ? error.message : "unknown"}`);
    return null;
  });
  const tweet = result?.data;
  if (!tweet) {
    console.error(`fetchTweetDetails ${postId}: no data in response ${JSON.stringify(result).slice(0, 400)}`);
    return null;
  }
  const username = (result?.includes?.users ?? []).find((u) => u.id === tweet.author_id)?.username ?? "";
  const key = tweet.attachments?.media_keys?.find((k) =>
    (result?.includes?.media ?? []).some((m) => m.media_key === k),
  );
  const mediaItem = (result?.includes?.media ?? []).find((m) => m.media_key === key);
  return {
    id: tweet.id,
    text: tweet.text,
    username,
    imageUrl: mediaItem?.url ?? mediaItem?.preview_image_url ?? null,
  };
}

/**
 * Short, human-readable reason for a failed X write. Safe to store and show on
 * public pages — never contains the raw API payload.
 */
export function friendlyXError(error: unknown): string {
  const message = error instanceof Error ? error.message : String(error ?? "");
  if (/cashtag/i.test(message)) return "X rejected the reply: more than one $cashtag in the text.";
  if (/duplicate content/i.test(message)) return "X rejected the reply as duplicate text.";
  if (/too many requests|rate.?limit|\[429\]/i.test(message)) return "X rate-limited the bot; it retries automatically.";
  if (/not-authorized|unauthorized|forbidden|\[401\]|\[403\]/i.test(message))
    return "X rejected the reply: the bot account was not allowed to post.";
  return "X rejected the reply.";
}

/** Post a reply to a tweet. Returns the new post id. */
export async function postReply(credentials: XCredentials, inReplyToPostId: string, text: string): Promise<string> {
  const safeText = enforceSingleCashtag(text);
  try {
    const result = await request<{ data: { id: string } }>(credentials, "POST", "/2/tweets", {
      body: { text: safeText, reply: { in_reply_to_tweet_id: inReplyToPostId } },
    });
    return result.data.id;
  } catch (error) {
    const message = error instanceof Error ? error.message : "";
    // X refuses identical text; our standard replies repeat, so retry once with
    // a short unique marker instead of silently never replying.
    if (!/duplicate content/i.test(message)) throw error;
    const marker = Date.now().toString(36).slice(-5).toUpperCase();
    const retry = await request<{ data: { id: string } }>(credentials, "POST", "/2/tweets", {
      body: { text: `${safeText}\n\nref ${marker}`, reply: { in_reply_to_tweet_id: inReplyToPostId } },
    });
    return retry.data.id;
  }
}
