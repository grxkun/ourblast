// SPDX-License-Identifier: BUSL-1.1
/**
 * OurBlast launch path for Perpsplexity (perpsplexity.app) virtual pools.
 *
 * Reproduces the official spot/bonding-curve launch exactly, traced from live
 * mainnet transactions (FLUFFY, MIZU, CAT — e.g.
 * FCzPY9ofieeTPMKwteuVq7qaENvUsG1UjGCUgnNq2Nko):
 *   1. Publish the embedded coin template with patched identifiers (mirrors
 *      @mysten/move-bytecode-template update_identifiers, which needs wasm we
 *      cannot run in the Worker) + 0x2::package::make_immutable.
 *   2. One atomic transaction: <coin>::create → settings::spot → split the
 *      1 SUI pool seed and the config's launch fee off the gas coin →
 *      launchpad::launch_registered<COIN, SUI> → transfer the returned
 *      PoolCap, LpPosition and change coin to the launch wallet.
 *
 * Fully backed / composite pools are deliberately NOT used: they require an
 * Aftermath clearing house plus a Suilend market and kept failing at
 * activation. A virtual pool is the raise-first curve, which is what a social
 * launch needs. Never fabricates a result: CONFIRMED only after Sui confirms
 * both steps and emits pool::PoolCreated.
 */

import { Transaction, type TransactionArgument } from "@mysten/sui/transactions";

import {
  encodeString,
  parseModule,
  readUleb,
  serializeModule,
} from "@/lib/terminal/coin-template.server";
import {
  PERPSPLEXITY_AFTERMATH_PACKAGE_ID,
  PERPSPLEXITY_COMPOSITE_BASE_FEE_BPS,
  PERPSPLEXITY_COMPOSITE_RESERVE_PARAM,
  PERPSPLEXITY_COMPOSITE_SETTINGS_ARGS,
  PERPSPLEXITY_COMPOSITE_SUPPLY,
  PERPSPLEXITY_CONFIG_ID,
  PERPSPLEXITY_CURVE_BASE_FEE_BPS,
  PERPSPLEXITY_CURVE_DEFAULT_CAP_UNITS,
  PERPSPLEXITY_CURVE_HIBERNATION,
  PERPSPLEXITY_CURVE_QUOTE_DECIMALS,
  PERPSPLEXITY_CURVE_QUOTE_TYPE,
  PERPSPLEXITY_CURVE_SEED_UNITS,
  PERPSPLEXITY_CURVE_SUPPLY,
  PERPSPLEXITY_ENGINE_PACKAGE_ID,
  PERPSPLEXITY_LAUNCHPAD_ID,
  PERPSPLEXITY_LENDING_MARKET_ID,
  PERPSPLEXITY_LENDING_TYPE,
  PERPSPLEXITY_ORIGINAL_PACKAGE_ID,
  PERPSPLEXITY_PACKAGE_ID,
  PERPSPLEXITY_REGISTRY_ID,
  type PerpsMarket,
  perpsCurveVirtualQuote,
  perpsLeverageBps,
  perpsQuoteUnits,
  resolvePerpsMarket,
} from "@/lib/terminal/perpsplexity";

import {
  type TxSigner,
  gasCoins,
  loadDeployer,
  normalizeType,
  referenceGasPrice,
  rpc,
  sharedRef,
  signAndExecute,
  withGas,
} from "@/lib/terminal/suipump-launch.server";

export interface PerpsLaunchInput {
  name: string;
  symbol: string;
  description: string;
  iconUrl: string;
  /** Kept for callers; virtual curves carry no perp market of their own. */
  underlying?: string | null;
  long?: boolean;
  leverageBps?: number | null;
  /** Starting market cap in USD; the curve is quoted in USDC, so 1:1. */
  startingCapUsd?: number | null;
  /** The launcher's own first buy on the new curve, in USDC. 0/null = none. */
  devBuyUsdc?: number | null;
  /**
   * The creator's own wallet, which funds and receives the first buy. The bot
   * wallet only ever pays gas, the launch fee and the 1 USDC pool seed — a
   * dev buy is never taken out of it. No buyer = the dev buy is skipped.
   */
  devBuyer?: { address: string; signer: TxSigner } | null;
}

/** Who pays for and receives the first buy, or why there won't be one. */
export interface DevBuyPlan {
  units: bigint;
  buyer: { address: string; signer: TxSigner } | null;
  skip: string | null;
}

export interface PerpsLaunchResult {
  status: "CONFIRMED" | "FAILED";
  digest: string | null;
  error: string | null;
  coinType: string | null;
  packageId: string | null;
  poolId: string | null;
  engineId: string | null;
  /** Set when an initial buy was requested and went through. */
  devBuyDigest?: string | null;
  /** Set when the launch confirmed but the initial buy did not. */
  devBuyError?: string | null;
}

/** Official coin template (sui 1.79.1), embedded verbatim in the frontend. */
const TEMPLATE_MODULE =
  "oRzrCwcAAAUJAQAOAg4kAzIlBFcEBVtPB6oBygEI9AJgCtQDDAzgAzMADgEUAggCCQIRAhUCFgADCAAAAQwAAQQHAAIFDAEAAQMACAADAgABAAEEBwQABgYCAAANAAEAAAoCAwADEAoLAQgECwQBAAQPAAQABRIIAQEMBhMFBgAFBwIJAQcIBwAHCAEHCAQIAggCCAIIAgcIBwILBQEIAAsDAQgAAQgGAQYIBwEFAQgBAgkABQEIAAcHCAQCCAIIAggCCAIHCAcCCwUBCQALAwEJAAxDb2luUmVnaXN0cnkKQ3JlYXRvckNhcBNDdXJyZW5jeUluaXRpYWxpemVyBE1FTUUGU3RyaW5nC1RyZWFzdXJ5Q2FwCVR4Q29udGV4dANVSUQEY29pbg1jb2luX3JlZ2lzdHJ5BmNyZWF0ZQZkZWxldGUCaWQEaW5pdARtZW1lA25ldwxuZXdfY3VycmVuY3kGb2JqZWN0D3B1YmxpY190cmFuc2ZlcgZzZW5kZXIGc3RyaW5nCHRyYW5zZmVyCnR4X2NvbnRleHQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAIAAgEMCAYBAgEMCAYAAAAAAQgKABEEEgELAC4RBjgAAgABAQAAAQwLABMBEQMLATEGCwMLAgsECwULBjgBAgAA";
const TEMPLATE_DEPENDENCIES = [
  "0x0000000000000000000000000000000000000000000000000000000000000001",
  "0x0000000000000000000000000000000000000000000000000000000000000002",
];

const CLOCK = "0x6";
const COIN_REGISTRY = "0x000000000000000000000000000000000000000000000000000000000000000c";
const IDENTIFIERS_KIND = 0x7;
const MOVE_KEYWORDS = new Set(
  "abort.acquires.as.break.const.continue.copy.else.entry.enum.false.friend.fun.has.if.invariant.let.loop.macro.match.module.move.mut.native.public.return.script.spec.struct.true.type.use.while".split("."),
);
const RESERVED_IDENTIFIERS = new Set([
  "id", "cap", "registry", "name", "symbol", "description", "ctx", "init",
  "create", "delete", "new", "sender", "coin", "object", "transfer",
  "string", "option", "url", "ascii", "tx_context", "coin_registry",
  "package", "types", "witness",
]);
const PUBLISH_BUDGET = 500_000_000;
const LAUNCH_BUDGET = 900_000_000;
const BUY_BUDGET = 300_000_000;
/** Headroom kept in the gas coin on top of the seed + launch fee. */
const GAS_HEADROOM_MIST = 1_000_000_000n;

function deriveNames(rawSymbol: string): { module: string; struct: string } {
  const symbol = rawSymbol.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 10);
  if (!/^[A-Z][A-Z0-9]{1,9}$/.test(symbol)) throw new Error("Ticker must be 2–10 letters/digits starting with a letter.");
  if (symbol === "UID" || symbol === "ID") throw new Error("That ticker is not allowed.");
  let module = symbol.toLowerCase();
  if (MOVE_KEYWORDS.has(module) || RESERVED_IDENTIFIERS.has(module)) module = `${module}_coin`;
  return { module, struct: symbol };
}

/** Patches the identifiers table (kind 0x7) — same result as update_identifiers. */
export function patchTemplateIdentifiers(
  moduleBase64: string,
  names: { module: string; struct: string },
): string {
  const bytes = new Uint8Array(Buffer.from(moduleBase64, "base64"));
  const parsed = parseModule(bytes);
  const index = parsed.tables.findIndex((table) => table.kind === IDENTIFIERS_KIND);
  const table = index >= 0 ? parsed.tables[index] : undefined;
  if (!table) throw new Error("Coin template has no identifiers table.");
  const body = parsed.body;
  const cursor = { offset: table.offset };
  const end = table.offset + table.length;
  // The identifiers table is a bare sequence of length-prefixed strings; the
  // table's own length delimits it, there is no leading count.
  const identifiers: string[] = [];
  while (cursor.offset < end) {
    const length = Number(readUleb(body, cursor));
    if (length <= 0 || cursor.offset + length > end) {
      throw new Error("Coin template identifiers table is malformed.");
    }
    identifiers.push(Buffer.from(body.slice(cursor.offset, cursor.offset + length)).toString("utf8"));
    cursor.offset += length;
  }
  if (cursor.offset !== end || !identifiers.includes("meme") || !identifiers.includes("MEME")) {
    throw new Error("Coin template identifiers table is malformed.");
  }
  const patched = identifiers.map((id) => (id === "meme" ? names.module : id === "MEME" ? names.struct : id));
  const tableBytes = patched.flatMap((id) => encodeString(id));
  const delta = tableBytes.length - table.length;
  const newBody = new Uint8Array(body.length + delta);
  newBody.set(body.slice(0, table.offset), 0);
  newBody.set(tableBytes, table.offset);
  newBody.set(body.slice(table.offset + table.length), table.offset + tableBytes.length);
  parsed.tables = parsed.tables.map((entry, entryIndex) => {
    if (entryIndex === index) return { ...entry, length: tableBytes.length };
    if (entry.offset > table.offset) return { ...entry, offset: entry.offset + delta };
    return entry;
  });
  parsed.body = newBody;
  return Buffer.from(serializeModule(parsed)).toString("base64");
}

async function objectRef(id: string, label: string): Promise<{ objectId: string; version: string; digest: string }> {
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const result = await rpc<{ data?: { version?: string; digest?: string } | null }>(
      "sui_getObject",
      [id, { showOwner: true }],
    ).catch(() => ({ data: null }));
    if (result.data?.version && result.data.digest) {
      return { objectId: id, version: String(result.data.version), digest: result.data.digest };
    }
    await new Promise((resolve) => setTimeout(resolve, 1500));
  }
  throw new Error(`${label} is not visible on chain yet.`);
}

async function readLaunchFeeMist(): Promise<bigint> {
  const result = await rpc<{
    data?: { content?: { fields?: { params?: { fields?: { launch_fee_mist?: string } }; paused?: boolean } } | null };
  }>("sui_getObject", [PERPSPLEXITY_CONFIG_ID, { showContent: true }]);
  const fields = result.data?.content?.fields;
  if (!fields) throw new Error("Could not read the Perpsplexity launch configuration.");
  if (fields.paused) throw new Error("Perpsplexity launches are paused right now.");
  return BigInt(fields.params?.fields?.launch_fee_mist ?? "0");
}

/**
 * Starting market cap in USDC base units. The curve is quoted in USDC, so a
 * requested USD cap is the cap — no price conversion is involved.
 */
function startingCapUnits(startingCapUsd: number | null | undefined): bigint {
  if (!startingCapUsd || startingCapUsd <= 0) return PERPSPLEXITY_CURVE_DEFAULT_CAP_UNITS;
  const units = perpsQuoteUnits(startingCapUsd.toFixed(PERPSPLEXITY_CURVE_QUOTE_DECIMALS));
  return units > PERPSPLEXITY_CURVE_SEED_UNITS ? units : PERPSPLEXITY_CURVE_DEFAULT_CAP_UNITS;
}

interface OwnedCoin {
  coinObjectId: string;
  version: string;
  digest: string;
  balance: string;
}

/** The wallet's USDC coin objects, largest first. */
async function quoteCoins(owner: string): Promise<OwnedCoin[]> {
  const result = await rpc<{ data?: OwnedCoin[] }>("suix_getCoins", [
    owner,
    PERPSPLEXITY_CURVE_QUOTE_TYPE,
    null,
    50,
  ]).catch(() => ({ data: [] as OwnedCoin[] }));
  return (result.data ?? []).slice().sort((a, b) => (BigInt(b.balance) > BigInt(a.balance) ? 1 : -1));
}

const quoteAmountText = (units: bigint) => (Number(units) / 10 ** PERPSPLEXITY_CURVE_QUOTE_DECIMALS).toString();

/** SUI the creator's own wallet needs to cover gas on its first buy. */
const DEV_BUY_GAS_MIST = 400_000_000n; // 0.4 SUI, covers the curve buy budget
const DEV_BUY_GAS_MIST_COMPOSITE = 1_600_000_000n; // 1.6 SUI for a composite buy

/**
 * Decides whether a first buy can happen and who pays. The bot wallet is never
 * the payer: without a funded creator wallet the buy is skipped and the launch
 * goes ahead untouched.
 */
export async function planDevBuy(input: PerpsLaunchInput): Promise<DevBuyPlan> {
  const units =
    input.devBuyUsdc && input.devBuyUsdc > 0
      ? perpsQuoteUnits(input.devBuyUsdc.toFixed(PERPSPLEXITY_CURVE_QUOTE_DECIMALS))
      : 0n;
  if (units === 0n) return { units: 0n, buyer: null, skip: null };

  const buyer = input.devBuyer ?? null;
  if (!buyer) {
    return {
      units: 0n,
      buyer: null,
      skip:
        `First buy skipped: it is paid from the creator's own OurBank wallet, and no wallet was available. ` +
        `The launch itself went ahead.`,
    };
  }

  const held = await quoteCoins(buyer.address);
  const balance = held.reduce((total, coin) => total + BigInt(coin.balance), 0n);
  if (balance < units) {
    return {
      units: 0n,
      buyer: null,
      skip:
        `First buy skipped: your OurBank wallet holds ${quoteAmountText(balance)} USDC, ` +
        `and the ${quoteAmountText(units)} USDC buy is paid from it. Top it up and buy on the pool.`,
    };
  }

  const needGas = input.underlying?.trim() ? DEV_BUY_GAS_MIST_COMPOSITE : DEV_BUY_GAS_MIST;
  const suiBalance = await rpc<{ totalBalance?: string }>("suix_getBalance", [buyer.address, "0x2::sui::SUI"])
    .then((result) => BigInt(result.totalBalance ?? "0"))
    .catch(() => 0n);
  if (suiBalance < needGas) {
    return {
      units: 0n,
      buyer: null,
      skip:
        `First buy skipped: your OurBank wallet needs about ${Number(needGas) / 1_000_000_000} SUI for network ` +
        `fees on the buy and holds ${Number(suiBalance) / 1_000_000_000} SUI. The launch itself went ahead.`,
    };
  }

  return { units, buyer, skip: null };
}


interface TxReceipt {
  ok: boolean;
  error: string | null;
  events: { type: string; parsedJson?: Record<string, unknown> }[];
  created: { objectId: string; objectType: string }[];
}

async function fetchReceipt(digest: string): Promise<TxReceipt> {
  const block = await rpc<{
    effects?: { status?: { status?: string; error?: string } };
    events?: { type?: string; parsedJson?: Record<string, unknown> }[];
    objectChanges?: { type: string; objectId?: string; objectType?: string }[];
  }>("sui_getTransactionBlock", [digest, { showEffects: true, showEvents: true, showObjectChanges: true }]);
  const ok = block.effects?.status?.status === "success";
  return {
    ok,
    error: ok ? null : block.effects?.status?.error ?? "Transaction failed.",
    events: (block.events ?? [])
      .filter((event) => typeof event.type === "string")
      .map((event) => ({ type: normalizeType(event.type as string), parsedJson: event.parsedJson ?? {} })),
    created: (block.objectChanges ?? [])
      .filter((change) => change.type === "created" && change.objectId && change.objectType)
      .map((change) => ({ objectId: change.objectId as string, objectType: normalizeType(change.objectType as string) })),
  };
}

function eventField(event: { parsedJson?: Record<string, unknown> } | undefined, key: string): string | null {
  const value = event?.parsedJson?.[key];
  return typeof value === "string" ? value : null;
}

function fail(error: string, extra: Partial<PerpsLaunchResult> = {}): PerpsLaunchResult {
  return {
    status: "FAILED",
    digest: extra.digest ?? null,
    error,
    coinType: extra.coinType ?? null,
    packageId: extra.packageId ?? null,
    poolId: extra.poolId ?? null,
    engineId: extra.engineId ?? null,
  };
}

/**
 * The creator's first buy on a live curve. Mirrors the pad's own buy
 * transaction: split the USDC amount, call pool::buy, keep the Position.
 * `sender` is the creator's own wallet — it pays the USDC and the gas, and it
 * receives the position. The bot wallet is never the buyer.
 */
export async function buyOnCurve(args: {
  keypair: TxSigner;
  sender: string;
  coinType: string;
  poolId: string;
  amount: bigint;
  gasPrice: number;
  freshGas: () => Promise<Awaited<ReturnType<typeof gasCoins>>>;
}): Promise<{ digest: string | null; error: string | null }> {
  try {
    const gas = await args.freshGas();
    if (gas.length === 0) return { digest: null, error: "No SUI coin was left to pay gas for the first buy." };
    const coins = await quoteCoins(args.sender);
    const primary = coins[0];
    if (!primary) return { digest: null, error: "The wallet held no USDC for the first buy." };
    const [poolRef, configRef, clockRef] = await Promise.all([
      sharedRef(args.poolId),
      sharedRef(PERPSPLEXITY_CONFIG_ID),
      sharedRef(CLOCK),
    ]);
    const tx = new Transaction();
    withGas(tx, args.sender, gas, args.gasPrice, BUY_BUDGET);
    const source = tx.objectRef({
      objectId: primary.coinObjectId,
      version: primary.version,
      digest: primary.digest,
    });
    if (BigInt(primary.balance) < args.amount && coins.length > 1) {
      tx.mergeCoins(
        source,
        coins
          .slice(1)
          .map((coin) => tx.objectRef({ objectId: coin.coinObjectId, version: coin.version, digest: coin.digest })),
      );
    }
    const [payment] = tx.splitCoins(source, [tx.pure.u64(args.amount)]);
    const position = tx.moveCall({
      target: `${PERPSPLEXITY_PACKAGE_ID}::pool::buy`,
      typeArguments: [args.coinType, PERPSPLEXITY_CURVE_QUOTE_TYPE],
      arguments: [
        tx.sharedObjectRef({ ...poolRef, mutable: true }),
        tx.sharedObjectRef({ ...configRef, mutable: false }),
        payment!,
        // No slippage floor: this is the very first trade on a fresh curve.
        tx.pure.u64(0),
        tx.pure.u64(BigInt(Date.now() + 300_000)),
        tx.sharedObjectRef({ ...clockRef, mutable: false }),
      ],
    });
    tx.transferObjects([position], args.sender);
    const run = await signAndExecute(tx, args.keypair);
    if (!run.ok || !run.digest) return { digest: null, error: run.error ?? "The first buy failed." };
    const receipt = await fetchReceipt(run.digest);
    if (!receipt.ok) return { digest: run.digest, error: receipt.error ?? "The first buy failed on chain." };
    return { digest: run.digest, error: null };
  } catch (error) {
    return { digest: null, error: (error as Error).message };
  }
}

// ===========================================================================
// Composite (market-backed) launches — a real leveraged position, e.g. NVDA 3L.
//
// Traced call-for-call from live mainnet composite launches:
//   prepare  G3h8YzA64pnBDJ2Y1CWuCQSJfNZDU3tKBqLrm7LbWvyF ($UNI, SUI 1.5x long)
//   activate BvJX1KU4G8Ahgz1Gj4daTUN2B5pTadTPab9LBa8YffWs
//   buy      3ukDrzndcLgHyx7ieGctzoTJjq6mX34Yfc3KeWLGCvTk
// Phase 1 (prepare_composite_registered) creates the coin, the Aftermath perp
// account, the engine and the pool in "prepared" state. Phase 2 must then run
// engine::activate + composite_pool::activate + clearing_house::share in one
// transaction, which opens the leveraged position and starts trading. A launch
// is only reported once composite_pool::Created is on chain.
// ===========================================================================

const COMPOSITE_PREPARE_BUDGET = 1_500_000_000;
const COMPOSITE_ACTIVATE_BUDGET = 1_500_000_000;
const COMPOSITE_BUY_BUDGET = 1_500_000_000;

/**
 * composite_pool::activate runs both price feeds through the module's private
 * `timely(&Clock, u64)` check, which aborts with code 6 when a feed's
 * timestamp is more than two minutes away from the on-chain clock. Read from
 * the module bytecode of
 * 0x70798463adae26d663d67b152e6531a4eaf48b541d6d3db11d730663dab20e8a.
 *
 * Crypto feeds (BTC, ETH, SOL, SUI, XRP …) update every few seconds around the
 * clock. Equity and commodity feeds (NVDA, TSLA, GOOGL, XAU …) stop publishing
 * when their market closes, so activation is impossible then — which is exactly
 * how the $GRAPHIC (NVDA) launch aborted after its coin was already published.
 * Checking first means a closed market costs the launcher nothing.
 */
const COMPOSITE_FEED_MAX_AGE_MS = 120_000;

async function feedTimestampMs(feedId: string): Promise<number | null> {
  const result = await rpc<{
    data?: { content?: { fields?: { feeds?: { fields?: { timestamp_ms?: string } }[] } } | null };
  }>("sui_getObject", [feedId, { showContent: true }]).catch(() => ({ data: null }));
  const stamp = result.data?.content?.fields?.feeds?.[0]?.fields?.timestamp_ms;
  return stamp ? Number(stamp) : null;
}

/**
 * Returns a launcher-facing reason when the market's feeds are too stale for
 * composite_pool::activate to succeed, or null when both are fresh.
 */
async function staleFeedReason(market: PerpsMarket): Promise<string | null> {
  const [baseMs, collateralMs] = await Promise.all([
    feedTimestampMs(market.baseOracleId),
    feedTimestampMs(market.collateralOracleId),
  ]);
  if (baseMs === null || collateralMs === null) {
    return `Perpsplexity's ${market.label} price feed could not be read right now, so the leveraged position cannot be opened. Nothing was launched — please try again shortly.`;
  }
  const now = Date.now();
  const stale = [
    { label: market.label, age: Math.abs(now - baseMs) },
    { label: "USDC", age: Math.abs(now - collateralMs) },
  ].filter((feed) => feed.age > COMPOSITE_FEED_MAX_AGE_MS);
  if (stale.length === 0) return null;
  const worst = stale.reduce((a, b) => (b.age > a.age ? b : a));
  const minutes = Math.round(worst.age / 60_000);
  return (
    `${market.label} cannot be launched right now: its ${worst.label} price feed last updated ` +
    `${minutes < 1 ? "over a minute" : `about ${minutes} minute${minutes === 1 ? "" : "s"}`} ago, and Perpsplexity ` +
    `only opens a leveraged position on a feed under two minutes old. Stock, index and metal markets stop ` +
    `publishing prices when they close, so try again when that market is open. Round-the-clock crypto markets ` +
    `such as BTC, ETH, SOL, SUI and XRP work at any hour. Nothing was launched and nothing was spent.`
  );
}

/** Every object phase 2 needs, taken from the Prepared event of phase 1. */
interface PreparedComposite {
  pool: string;
  engine: string;
  engineAccount: string;
  engineSleeve: string;
  engineVault: string;
  poolSleeve: string;
  reserve: string;
  reserveAccount: string;
  poolCap: { objectId: string; version: string; digest: string };
}

/** Shared-object references phase 2 and composite buys both need. */
async function compositeRefs(prepared: PreparedComposite, market: PerpsMarket) {
  const [
    pool,
    config,
    engine,
    engineVault,
    engineAccount,
    clearingHouse,
    engineSleeve,
    lendingMarket,
    poolSleeve,
    reserve,
    reserveAccount,
    registry,
    baseFeed,
    collateralFeed,
    clock,
  ] = await Promise.all([
    sharedRef(prepared.pool),
    sharedRef(PERPSPLEXITY_CONFIG_ID),
    sharedRef(prepared.engine),
    sharedRef(prepared.engineVault),
    sharedRef(prepared.engineAccount),
    sharedRef(market.marketId),
    sharedRef(prepared.engineSleeve),
    sharedRef(PERPSPLEXITY_LENDING_MARKET_ID),
    sharedRef(prepared.poolSleeve),
    sharedRef(prepared.reserve),
    sharedRef(prepared.reserveAccount),
    sharedRef(PERPSPLEXITY_REGISTRY_ID),
    sharedRef(market.baseOracleId),
    sharedRef(market.collateralOracleId),
    sharedRef(CLOCK),
  ]);
  return {
    pool,
    config,
    engine,
    engineVault,
    engineAccount,
    clearingHouse,
    engineSleeve,
    lendingMarket,
    poolSleeve,
    reserve,
    reserveAccount,
    registry,
    baseFeed,
    collateralFeed,
    clock,
  };
}

type CompositeRefs = Awaited<ReturnType<typeof compositeRefs>>;

/**
 * Appends the public composite trading path — cash_prices -> buy_cash -> the
 * Position<T> to the buyer — onto an existing transaction. Kept separate so the
 * creator's first buy can either run on its own or ride inside the activation
 * transaction, where no sniper can slip in front of it.
 * composite_pool::buy is deliberately unused: it is a low-level margin path
 * that aborts in the clearing house's private active() check.
 */
export function appendCompositeBuy(
  tx: Transaction,
  args: {
    coinType: string;
    refs: CompositeRefs;
    buyer: string;
    coins: OwnedCoin[];
    amount: bigint;
    /** The ClearingHouse returned by activate, when bundled before share. */
    clearingHouse?: TransactionArgument;
  },
): void {
  const primary = args.coins[0]!;
  const source = tx.objectRef({
    objectId: primary.coinObjectId,
    version: primary.version,
    digest: primary.digest,
  });
  if (BigInt(primary.balance) < args.amount && args.coins.length > 1) {
    tx.mergeCoins(
      source,
      args.coins
        .slice(1)
        .map((coin) => tx.objectRef({ objectId: coin.coinObjectId, version: coin.version, digest: coin.digest })),
    );
  }
  const [payment] = tx.splitCoins(source, [tx.pure.u64(args.amount)]);
  const typeArguments = [args.coinType, PERPSPLEXITY_LENDING_TYPE, PERPSPLEXITY_CURVE_QUOTE_TYPE];
  const [cashPrices] = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::composite_pool::cash_prices`,
    typeArguments,
    arguments: [
      tx.sharedObjectRef({ ...args.refs.pool, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.engine, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.engineVault, mutable: false }),
      args.clearingHouse ?? tx.sharedObjectRef({ ...args.refs.clearingHouse, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.collateralFeed, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.clock, mutable: false }),
    ],
  }) as TransactionArgument[];
  const [position] = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::composite_pool::buy_cash`,
    typeArguments,
    arguments: [
      tx.sharedObjectRef({ ...args.refs.pool, mutable: true }),
      tx.sharedObjectRef({ ...args.refs.config, mutable: false }),
      // The pool's own sleeve, reserve and reserve account — not the engine's.
      // The engine pair aborts in basket::check_cash; these match every live
      // buy_cash trade on chain.
      tx.sharedObjectRef({ ...args.refs.poolSleeve, mutable: true }),
      tx.sharedObjectRef({ ...args.refs.reserve, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.reserveAccount, mutable: false }),
      tx.sharedObjectRef({ ...args.refs.lendingMarket, mutable: true }),
      payment!,
      cashPrices!,
      // No minimum output: this is the creator's optional first trade on its
      // newly confirmed pool, matching the successful dev-inspected flow.
      tx.pure.u64(0),
      // Stay inside Perpsplexity's two-minute timely() window.
      tx.pure.u64(BigInt(Date.now() + 60_000)),
      tx.sharedObjectRef({ ...args.refs.clock, mutable: false }),
    ],
  }) as TransactionArgument[];
  tx.transferObjects([position!], args.buyer);
}

/**
 * The creator's first buy as its own transaction, used when the pool was
 * already live (a retry) rather than bundled into activation. `sender` is
 * always the creator's wallet, so both the USDC payment and the resulting
 * Position<T> stay completely separate from the bot wallet.
 */
export async function buyOnCompositePool(args: {
  keypair: TxSigner;
  sender: string;
  coinType: string;
  prepared: PreparedComposite;
  market: PerpsMarket;
  amount: bigint;
  gasPrice: number;
  freshGas: () => Promise<Awaited<ReturnType<typeof gasCoins>>>;
}): Promise<{ digest: string | null; error: string | null }> {
  try {
    const gas = await args.freshGas();
    if (gas.length === 0) return { digest: null, error: "No SUI coin was left to pay gas for the first buy." };
    const coins = await quoteCoins(args.sender);
    if (coins.length === 0) return { digest: null, error: "The wallet held no USDC for the first buy." };
    const refs = await compositeRefs(args.prepared, args.market);
    const tx = new Transaction();
    withGas(tx, args.sender, gas, args.gasPrice, COMPOSITE_BUY_BUDGET);
    appendCompositeBuy(tx, {
      coinType: args.coinType,
      refs,
      buyer: args.sender,
      coins,
      amount: args.amount,
    });
    const run = await signAndExecute(tx, args.keypair);
    if (!run.ok || !run.digest) return { digest: null, error: run.error ?? "The first buy failed." };
    const receipt = await fetchReceipt(run.digest);
    if (!receipt.ok) return { digest: run.digest, error: receipt.error ?? "The first buy failed on chain." };
    return { digest: run.digest, error: null };
  } catch (error) {
    return { digest: null, error: (error as Error).message };
  }
}

/**
 * Phase 1 + phase 2 of a composite launch, run after the coin package is
 * published. Returns CONFIRMED only once composite_pool::Created is on chain.
 */
async function launchCompositePool(args: {
  keypair: NonNullable<Awaited<ReturnType<typeof loadDeployer>>>;
  sender: string;
  names: { module: string; struct: string };
  packageId: string;
  coinType: string;
  capRef: { objectId: string; version: string; digest: string };
  name: string;
  description: string;
  iconUrl: string;
  market: PerpsMarket;
  long: boolean;
  leverageBps: number;
  virtualQuote: bigint;
  launchFeeMist: bigint;
  devBuy: DevBuyPlan;
  gasPrice: number;
  freshGas: () => Promise<Awaited<ReturnType<typeof gasCoins>>>;
  freshGasFor: (address: string) => Promise<Awaited<ReturnType<typeof gasCoins>>>;
}): Promise<PerpsLaunchResult> {
  const { coinType, packageId, market, sender } = args;

  // ---- Phase 1: prepare_composite_registered -----------------------------
  const [launchpadRef, configRef, clockRef, coinRegistryRef, registryRef, clearingHouseRef, lendingRef, baseFeedRef, collateralFeedRef] =
    await Promise.all([
      sharedRef(PERPSPLEXITY_LAUNCHPAD_ID),
      sharedRef(PERPSPLEXITY_CONFIG_ID),
      sharedRef(CLOCK),
      sharedRef(COIN_REGISTRY),
      sharedRef(PERPSPLEXITY_REGISTRY_ID),
      sharedRef(market.marketId),
      sharedRef(PERPSPLEXITY_LENDING_MARKET_ID),
      sharedRef(market.baseOracleId),
      sharedRef(market.collateralOracleId),
    ]);

  const prepareGas = await args.freshGas();
  if (prepareGas.length === 0) {
    return fail("The bot wallet has no SUI coin left to pay gas.", { coinType, packageId });
  }
  const seedSource = await quoteCoins(sender);
  const seedPrimary = seedSource[0];
  if (!seedPrimary) return fail("The bot wallet holds no USDC to seed the pool.", { coinType, packageId });

  const tx = new Transaction();
  withGas(tx, sender, prepareGas, args.gasPrice, COMPOSITE_PREPARE_BUDGET);
  const createResults = tx.moveCall({
    target: `${packageId}::${args.names.module}::create`,
    arguments: [
      tx.objectRef(args.capRef),
      tx.sharedObjectRef({ ...coinRegistryRef, mutable: true }),
      tx.pure.string(args.name.trim()),
      tx.pure.string(args.names.struct),
      tx.pure.string(args.description),
      tx.pure.string(args.iconUrl),
    ],
  }) as TransactionArgument[];
  const initializer = createResults[0]!;
  const treasuryCap = createResults[1]!;
  const settings = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::settings::new`,
    arguments: PERPSPLEXITY_COMPOSITE_SETTINGS_ARGS.map((value) =>
      typeof value === "boolean" ? tx.pure.bool(value) : tx.pure.u64(value),
    ),
  });
  const primaryQuote = tx.objectRef({
    objectId: seedPrimary.coinObjectId,
    version: seedPrimary.version,
    digest: seedPrimary.digest,
  });
  if (BigInt(seedPrimary.balance) < PERPSPLEXITY_CURVE_SEED_UNITS && seedSource.length > 1) {
    tx.mergeCoins(
      primaryQuote,
      seedSource
        .slice(1)
        .map((coin) => tx.objectRef({ objectId: coin.coinObjectId, version: coin.version, digest: coin.digest })),
    );
  }
  const [seedCoin] = tx.splitCoins(primaryQuote, [tx.pure.u64(PERPSPLEXITY_CURVE_SEED_UNITS)]);
  const [feeCoin] = tx.splitCoins(tx.gas, [tx.pure.u64(args.launchFeeMist)]);
  const prepareResults = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::launchpad::prepare_composite_registered`,
    typeArguments: [coinType, PERPSPLEXITY_LENDING_TYPE, PERPSPLEXITY_CURVE_QUOTE_TYPE],
    arguments: [
      tx.sharedObjectRef({ ...launchpadRef, mutable: true }),
      tx.sharedObjectRef({ ...configRef, mutable: false }),
      treasuryCap,
      initializer,
      tx.sharedObjectRef({ ...registryRef, mutable: true }),
      tx.sharedObjectRef({ ...clearingHouseRef, mutable: false }),
      tx.sharedObjectRef({ ...lendingRef, mutable: false }),
      tx.sharedObjectRef({ ...baseFeedRef, mutable: false }),
      tx.sharedObjectRef({ ...collateralFeedRef, mutable: false }),
      seedCoin!,
      feeCoin!,
      tx.pure.u64(PERPSPLEXITY_COMPOSITE_SUPPLY),
      settings,
      tx.pure.u64(PERPSPLEXITY_COMPOSITE_BASE_FEE_BPS),
      tx.pure.bool(args.long),
      tx.pure.u64(args.leverageBps),
      tx.pure.u64(PERPSPLEXITY_COMPOSITE_RESERVE_PARAM),
      tx.pure.u64(args.virtualQuote),
      tx.sharedObjectRef({ ...clockRef, mutable: false }),
    ],
  }) as TransactionArgument[];
  // The cap is required again by phase 2, which the bot wallet sends.
  tx.transferObjects([prepareResults[0]!], sender);
  tx.transferObjects([prepareResults[1]!], sender);

  const prepareRun = await signAndExecute(tx, args.keypair);
  if (!prepareRun.ok || !prepareRun.digest) {
    return fail(prepareRun.error ?? "Preparing the leveraged pool failed.", {
      digest: prepareRun.digest,
      coinType,
      packageId,
    });
  }
  const prepareReceipt = await fetchReceipt(prepareRun.digest);
  if (!prepareReceipt.ok) {
    return fail(prepareReceipt.error ?? "Preparing the leveraged pool failed on chain.", {
      digest: prepareRun.digest,
      coinType,
      packageId,
    });
  }
  const preparedEvent = prepareReceipt.events.find(
    (event) => event.type === `${PERPSPLEXITY_ORIGINAL_PACKAGE_ID}::composite_pool::Prepared`,
  );
  const poolCapObject = prepareReceipt.created.find((change) =>
    change.objectType.endsWith("::composite_pool::PoolCap"),
  );
  const field = (key: string) => eventField(preparedEvent, key);
  const poolId = field("pool");
  if (!preparedEvent || !poolId || !poolCapObject) {
    return fail("The leveraged pool was not confirmed on chain.", {
      digest: prepareRun.digest,
      coinType,
      packageId,
    });
  }

  let poolCapRef: { objectId: string; version: string; digest: string };
  try {
    poolCapRef = await objectRef(poolCapObject.objectId, "The pool capability");
  } catch (error) {
    return fail((error as Error).message, { digest: prepareRun.digest, coinType, packageId, poolId });
  }

  const prepared: PreparedComposite = {
    pool: poolId,
    engine: field("engine") ?? "",
    engineAccount: field("engine_account") ?? "",
    engineSleeve: field("engine_sleeve") ?? "",
    engineVault: field("engine_vault") ?? "",
    poolSleeve: field("pool_sleeve") ?? "",
    reserve: field("reserve") ?? "",
    reserveAccount: field("reserve_account") ?? "",
    poolCap: poolCapRef,
  };
  if (Object.values(prepared).some((value) => value === "")) {
    return fail("The leveraged pool was prepared but its engine objects could not be read.", {
      digest: prepareRun.digest,
      coinType,
      packageId,
      poolId,
    });
  }

  return activateComposite({
    keypair: args.keypair,
    sender,
    coinType,
    packageId,
    prepared,
    market,
    devBuy: args.devBuy,
    gasPrice: args.gasPrice,
    freshGas: args.freshGas,
    freshGasFor: args.freshGasFor,
    prepareDigest: prepareRun.digest,
  });
}

/**
 * Moves exactly the creator's first-buy USDC into the bot wallet, sent and
 * gas-paid by the creator. The bot then spends that very coin inside the
 * activation block and delivers the Position to the creator, so the bot's own
 * USDC is never touched.
 */
async function escrowCreatorUsdc(args: {
  buyer: { address: string; signer: TxSigner };
  bot: string;
  amount: bigint;
  gasPrice: number;
  freshGas: () => Promise<Awaited<ReturnType<typeof gasCoins>>>;
}): Promise<{ coin: OwnedCoin | null; error: string | null }> {
  try {
    const gas = await args.freshGas();
    if (gas.length === 0) return { coin: null, error: "The creator wallet had no SUI for gas." };
    const coins = await quoteCoins(args.buyer.address);
    if (coins.length === 0) return { coin: null, error: "The creator wallet held no USDC for the first buy." };
    const tx = new Transaction();
    withGas(tx, args.buyer.address, gas, args.gasPrice, COMPOSITE_BUY_BUDGET);
    const primary = tx.objectRef({ objectId: coins[0]!.coinObjectId, version: coins[0]!.version, digest: coins[0]!.digest });
    if (coins.length > 1) {
      tx.mergeCoins(primary, coins.slice(1).map((c) => tx.objectRef({ objectId: c.coinObjectId, version: c.version, digest: c.digest })));
    }
    const [part] = tx.splitCoins(primary, [tx.pure.u64(args.amount)]);
    tx.transferObjects([part!], args.bot);
    const run = await signAndExecute(tx, args.buyer.signer);
    if (!run.ok || !run.digest) return { coin: null, error: run.error ?? "Moving the first-buy USDC failed." };
    const receipt = await fetchReceipt(run.digest);
    const created = receipt.created.find((change) => change.objectType.includes("::coin::Coin<"));
    if (!receipt.ok || !created) return { coin: null, error: receipt.error ?? "The first-buy USDC transfer was not confirmed." };
    const ref = await objectRef(created.objectId, "The first-buy USDC");
    return { coin: { coinObjectId: ref.objectId, version: ref.version, digest: ref.digest, balance: args.amount.toString() }, error: null };
  } catch (error) {
    return { coin: null, error: (error as Error).message };
  }
}

/**
 * Phase 2: engine::activate + composite_pool::activate (+ the creator's first
 * buy) + share, all sent and paid by the bot wallet in one atomic block.
 *
 * Snipers land a buy_cash within a second of composite_pool::Created, so a
 * planned first buy rides inside this very transaction. It must read the
 * ClearingHouse returned by activate *before* that value is shared.
 * Exported so an already-prepared pool can be activated without redoing phase 1.
 */
export async function activateComposite(args: {
  keypair: NonNullable<Awaited<ReturnType<typeof loadDeployer>>>;
  sender: string;
  coinType: string;
  packageId: string;
  prepared: PreparedComposite;
  market: PerpsMarket;
  devBuy: DevBuyPlan;
  gasPrice: number;
  freshGas: () => Promise<Awaited<ReturnType<typeof gasCoins>>>;
  freshGasFor: (address: string) => Promise<Awaited<ReturnType<typeof gasCoins>>>;
  prepareDigest: string;
  /** A creator USDC coin already moved to the bot for this buy (resume path). */
  escrowCoin?: OwnedCoin | null;
}): Promise<PerpsLaunchResult> {
  const { coinType, packageId, market, sender, prepared } = args;
  const poolId = prepared.pool;
  const buyer = args.devBuy.units > 0n ? args.devBuy.buyer : null;

  let escrow: OwnedCoin | null = args.escrowCoin ?? null;
  let devBuyError: string | null = args.devBuy.skip;
  if (buyer && !escrow) {
    const moved = await escrowCreatorUsdc({
      buyer,
      bot: sender,
      amount: args.devBuy.units,
      gasPrice: args.gasPrice,
      freshGas: () => args.freshGasFor(buyer.address),
    });
    escrow = moved.coin;
    if (!escrow) devBuyError = `First buy skipped: ${moved.error}`;
  }

  /**
   * Hand the escrowed first-buy USDC back to the creator. Returns null on
   * success, or an error message when the refund could not be sent — the
   * caller must surface that message so the money is never silently stranded
   * in the bot wallet.
   */
  const refundEscrow = async (): Promise<string | null> => {
    if (!buyer || !escrow) return null;
    const refundGas = await args.freshGas();
    if (refundGas.length === 0) {
      return "The bot wallet has no SUI coin left to return the first-buy USDC.";
    }
    const refundTx = new Transaction();
    withGas(refundTx, sender, refundGas, args.gasPrice, COMPOSITE_BUY_BUDGET);
    refundTx.transferObjects(
      [refundTx.objectRef({ objectId: escrow.coinObjectId, version: escrow.version, digest: escrow.digest })],
      buyer.address,
    );
    const refund = await signAndExecute(refundTx, args.keypair);
    if (!refund.ok || !refund.digest) {
      return `The first-buy USDC could not be returned to the creator: ${refund.error ?? "transfer failed"}.`;
    }
    await fetchReceipt(refund.digest);
    return null;
  };

  const refs = await compositeRefs(prepared, market);
  let activateGas = await args.freshGas();
  if (activateGas.length === 0) {
    const refundError = await refundEscrow();
    return fail(
      `The bot wallet has no SUI coin left to activate the leveraged position.${refundError ? ` ${refundError}` : escrow ? " The first-buy USDC was returned to the creator." : ""}`,
      {
        digest: args.prepareDigest,
        coinType,
        packageId,
        poolId,
      },
    );
  }

  const buildActivate = (includeBuy: boolean) => {
    const activateTx = new Transaction();
    withGas(activateTx, sender, activateGas, args.gasPrice, COMPOSITE_ACTIVATE_BUDGET);
    const engineRef = activateTx.sharedObjectRef({ ...refs.engine, mutable: true });
    const engineVaultRef = activateTx.sharedObjectRef({ ...refs.engineVault, mutable: true });
    const engineAccountRef = activateTx.sharedObjectRef({ ...refs.engineAccount, mutable: true });
    const clearingHouseArg = activateTx.sharedObjectRef({ ...refs.clearingHouse, mutable: true });
    activateTx.moveCall({
      target: `${PERPSPLEXITY_ENGINE_PACKAGE_ID}::engine::activate`,
      typeArguments: [PERPSPLEXITY_LENDING_TYPE, PERPSPLEXITY_CURVE_QUOTE_TYPE],
      arguments: [engineRef, engineVaultRef, engineAccountRef, clearingHouseArg],
    });
    const activateResults = activateTx.moveCall({
      target: `${PERPSPLEXITY_PACKAGE_ID}::composite_pool::activate`,
      typeArguments: [coinType, PERPSPLEXITY_LENDING_TYPE, PERPSPLEXITY_CURVE_QUOTE_TYPE],
      arguments: [
        activateTx.sharedObjectRef({ ...refs.pool, mutable: true }),
        activateTx.sharedObjectRef({ ...refs.config, mutable: false }),
        activateTx.objectRef(prepared.poolCap),
        engineRef,
        engineVaultRef,
        engineAccountRef,
        clearingHouseArg,
        activateTx.sharedObjectRef({ ...refs.engineSleeve, mutable: true }),
        activateTx.sharedObjectRef({ ...refs.lendingMarket, mutable: true }),
        activateTx.sharedObjectRef({ ...refs.poolSleeve, mutable: true }),
        activateTx.sharedObjectRef({ ...refs.reserve, mutable: false }),
        activateTx.sharedObjectRef({ ...refs.reserveAccount, mutable: true }),
        activateTx.sharedObjectRef({ ...refs.registry, mutable: false }),
        activateTx.sharedObjectRef({ ...refs.baseFeed, mutable: false }),
        activateTx.sharedObjectRef({ ...refs.collateralFeed, mutable: false }),
        // Same floor as the live $diana activation: 99% of the 1 USDC seed NAV.
        activateTx.pure.u64(989_999n),
        // composite_pool::timely rejects deadlines more than 120s ahead.
        activateTx.pure.u64(BigInt(Date.now() + 60_000)),
        activateTx.sharedObjectRef({ ...refs.clock, mutable: false }),
      ],
    }) as TransactionArgument[];
    if (includeBuy && buyer && escrow) {
      // activate consumed the shared ClearingHouse by value; the buy reads the
      // returned one before it is shared again.
      appendCompositeBuy(activateTx, {
        coinType,
        refs,
        buyer: buyer.address,
        coins: [escrow],
        amount: args.devBuy.units,
        clearingHouse: activateResults[0]!,
      });
    }
    activateTx.moveCall({
      target: `${PERPSPLEXITY_AFTERMATH_PACKAGE_ID}::clearing_house::share`,
      typeArguments: [PERPSPLEXITY_CURVE_QUOTE_TYPE],
      arguments: [activateResults[0]!],
    });
    activateTx.transferObjects([activateResults[1]!], sender);
    return activateTx;
  };

  let bundledBuy = Boolean(buyer && escrow);
  let activateRun = await signAndExecute(buildActivate(bundledBuy), args.keypair);
  if (bundledBuy && (!activateRun.ok || !activateRun.digest)) {
    // The bundled buy is best effort: activate alone rather than lose the launch.
    bundledBuy = false;
    activateGas = await args.freshGas();
    activateRun = await signAndExecute(buildActivate(false), args.keypair);
  }
  if (!activateRun.ok || !activateRun.digest) {
    const refundError = await refundEscrow();
    return fail(
      `The leveraged position could not be opened: ${activateRun.error ?? "activation failed"}. The pool is prepared but not trading.${refundError ? ` ${refundError}` : escrow ? " The first-buy USDC was returned to the creator." : ""}`,
      { digest: args.prepareDigest, coinType, packageId, poolId },
    );
  }
  const activateReceipt = await fetchReceipt(activateRun.digest);
  const createdEvent = activateReceipt.events.find(
    (event) => event.type === `${PERPSPLEXITY_ORIGINAL_PACKAGE_ID}::composite_pool::Created`,
  );
  if (!activateReceipt.ok || !createdEvent) {
    const refundError = await refundEscrow();
    return fail(
      `The leveraged position could not be opened: ${activateReceipt.error ?? "activation was not confirmed"}. The pool is prepared but not trading.${refundError ? ` ${refundError}` : escrow ? " The first-buy USDC was returned to the creator." : ""}`,
      { digest: activateRun.digest, coinType, packageId, poolId },
    );
  }

  let devBuyDigest: string | null = null;
  if (bundledBuy) {
    devBuyDigest = activateRun.digest;
    devBuyError = null;
  } else if (buyer && escrow) {
    // Bundle failed: hand the creator's USDC back, then buy from their wallet.
    // Only buy from the creator's wallet once their escrowed USDC is confirmed
    // back with them — otherwise the same money would be spent twice.
    const refundError = await refundEscrow();
    if (refundError) {
      devBuyError = `First buy skipped: ${refundError}`;
    } else {
      const outcome = await buyOnCompositePool({
        keypair: buyer.signer,
        sender: buyer.address,
        coinType,
        prepared,
        market,
        amount: args.devBuy.units,
        gasPrice: args.gasPrice,
        freshGas: () => args.freshGasFor(buyer.address),
      });
      devBuyDigest = outcome.digest;
      devBuyError = outcome.error;
    }
  }

  return {
    status: "CONFIRMED",
    digest: activateRun.digest,
    error: null,
    coinType,
    packageId,
    poolId,
    engineId: prepared.engine,
    devBuyDigest,
    devBuyError,
  };
}



export async function launchOnPerpsplexity(input: PerpsLaunchInput): Promise<PerpsLaunchResult> {
  const keypair = await loadDeployer();
  if (!keypair) return fail("The bot launch wallet is not configured.");
  const sender = keypair.getPublicKey().toSuiAddress();

  let names: { module: string; struct: string };
  try {
    names = deriveNames(input.symbol);
  } catch (error) {
    return fail((error as Error).message);
  }

  // A named underlying market means a genuine leveraged pool (e.g. NVDA 3L);
  // without one the launch is the plain USDC bonding curve.
  const market = resolvePerpsMarket(input.underlying);
  if (input.underlying && input.underlying.trim() && !market) {
    return fail(
      `Perpsplexity has no market for "${input.underlying.trim()}". Pick one of its listed markets, or leave it out for a plain curve.`,
    );
  }
  let leverageBps = 0;
  if (market) {
    try {
      leverageBps = perpsLeverageBps(input.leverageBps);
    } catch (error) {
      return fail((error as Error).message);
    }
  }

  // Checked before anything is published or paid for: a closed market's price
  // feed goes stale and activation would abort, leaving a coin behind that can
  // never trade.
  if (market) {
    const staleReason = await staleFeedReason(market);
    if (staleReason) return fail(staleReason);
  }

  let launchFeeMist: bigint;
  try {
    launchFeeMist = await readLaunchFeeMist();
  } catch (error) {
    return fail((error as Error).message);
  }

  let virtualQuote: bigint;
  try {
    virtualQuote = perpsCurveVirtualQuote(startingCapUnits(input.startingCapUsd));
  } catch (error) {
    return fail((error as Error).message);
  }

  // The curve is seeded in USDC. The bot wallet only ever covers the 1 USDC
  // pool seed — the first buy is funded by the creator's own wallet, so a
  // stranger's "dev buy 500" can never drain the bot.
  const quoteHeld = await quoteCoins(sender);
  const quoteBalance = quoteHeld.reduce((total, coin) => total + BigInt(coin.balance), 0n);
  if (quoteBalance < PERPSPLEXITY_CURVE_SEED_UNITS) {
    return fail(
      `The bot wallet needs ${quoteAmountText(PERPSPLEXITY_CURVE_SEED_UNITS)} USDC for the pool seed; ` +
        `it holds ${quoteAmountText(quoteBalance)} USDC.`,
    );
  }

  const [gas, gasPrice] = await Promise.all([gasCoins(sender), referenceGasPrice().catch(() => 1000)]);
  if (gas.length === 0) return fail("The bot wallet has no SUI for gas or the launch fee.");
  // Every transaction consumes and recreates the gas coin, so its version and
  // digest change. Reusing a stale reference makes the node reject the next
  // transaction, so each step re-reads the wallet's current coins.
  const freshGasFor = async (address: string): Promise<typeof gas> => {
    for (let attempt = 0; attempt < 8; attempt += 1) {
      const coins = await gasCoins(address).catch(() => []);
      if (coins.length > 0) return coins;
      await new Promise((resolve) => setTimeout(resolve, 1500));
    }
    return [];
  };
  const freshGas = () => freshGasFor(sender);

  // Who pays for the first buy: the creator, out of their own OurBank wallet.
  // Anything that would put it on the bot instead turns into a skip notice, and
  // the launch itself carries on regardless.
  const devBuy = await planDevBuy(input);

  const description =
    input.description.trim() || `${input.name} — bonding-curve memecoin on Perpsplexity, launched via OurBlast.`;

  // Step 1 — publish the coin package (official flow: publish patched
  // template modules, then make the upgrade cap immutable).
  let moduleBase64: string;
  try {
    moduleBase64 = patchTemplateIdentifiers(TEMPLATE_MODULE, names);
  } catch (error) {
    return fail(`Could not patch the coin template: ${(error as Error).message}`);
  }
  const publishTx = new Transaction();
  withGas(publishTx, sender, gas, gasPrice, PUBLISH_BUDGET);
  const [upgradeCap] = publishTx.publish({
    modules: [Array.from(Buffer.from(moduleBase64, "base64"))],
    dependencies: TEMPLATE_DEPENDENCIES,
  });
  publishTx.moveCall({ target: "0x2::package::make_immutable", arguments: [upgradeCap!] });
  const publishRun = await signAndExecute(publishTx, keypair);
  if (!publishRun.ok || !publishRun.digest) return fail(publishRun.error ?? "Coin package publish failed.");
  const publishReceipt = await fetchReceipt(publishRun.digest);
  if (!publishReceipt.ok) return fail(publishReceipt.error ?? "Coin package publish failed on chain.");
  const creatorCap = publishReceipt.created.find((change) => change.objectType.endsWith("::CreatorCap"));
  if (!creatorCap) return fail("The coin package published but no creator capability appeared.");
  const packageId = creatorCap.objectType.split("::")[0]!;
  const coinType = `${packageId}::${names.module}::${names.struct}`;

  // Step 2 — the virtual pool launch: one atomic launch_registered call.
  let capRef: { objectId: string; version: string; digest: string };
  try {
    capRef = await objectRef(creatorCap.objectId, "The coin creator capability");
  } catch (error) {
    return fail((error as Error).message, { coinType, packageId });
  }

  // A leveraged (composite) pool takes its own two-phase path from here.
  if (market) {
    return launchCompositePool({
      keypair,
      sender,
      names,
      packageId,
      coinType,
      capRef,
      name: input.name,
      description,
      iconUrl: input.iconUrl,
      market,
      long: input.long !== false,
      leverageBps,
      virtualQuote,
      launchFeeMist,
      devBuy,
      gasPrice,
      freshGas,
      freshGasFor,
    });
  }

  const [launchpadRef, configRef, clockRef, coinRegistryRef] = await Promise.all([
    sharedRef(PERPSPLEXITY_LAUNCHPAD_ID),
    sharedRef(PERPSPLEXITY_CONFIG_ID),
    sharedRef(CLOCK),
    // Sui's coin registry is a shared object with a real initial version; a
    // hardcoded version 1 makes the whole launch unusable on chain.
    sharedRef(COIN_REGISTRY),
  ]);

  const launchGas = await freshGas();
  if (launchGas.length === 0) {
    return fail(
      "The bot wallet has no SUI coin left to pay gas. Send a few SUI to it with a normal transfer, then launch again.",
      { coinType, packageId },
    );
  }
  // Only the launch fee and gas come out of SUI now; the pool seed is USDC.
  const needed = launchFeeMist + GAS_HEADROOM_MIST;
  const balance = await rpc<{ totalBalance?: string }>("suix_getBalance", [sender, "0x2::sui::SUI"])
    .then((result) => BigInt(result.totalBalance ?? "0"))
    .catch(() => 0n);
  if (balance > 0n && balance < needed) {
    return fail(
      `The bot wallet needs about ${Number(needed) / 1_000_000_000} SUI for the ${Number(launchFeeMist) / 1_000_000_000} SUI launch fee and gas.`,
      { coinType, packageId },
    );
  }
  // Fresh USDC coin references: the balance check above ran before the publish.
  const seedSource = await quoteCoins(sender);
  const seedPrimary = seedSource[0];
  if (!seedPrimary) return fail("The bot wallet holds no USDC to seed the curve.", { coinType, packageId });

  const tx = new Transaction();
  withGas(tx, sender, launchGas, gasPrice, LAUNCH_BUDGET);
  const createResults = tx.moveCall({
    target: `${packageId}::${names.module}::create`,
    arguments: [
      tx.objectRef(capRef),
      tx.sharedObjectRef({ ...coinRegistryRef, mutable: true }),
      tx.pure.string(input.name.trim()),
      tx.pure.string(names.struct),
      tx.pure.string(description),
      tx.pure.string(input.iconUrl),
    ],
  }) as TransactionArgument[];
  const initializer = createResults[0]!;
  const treasuryCap = createResults[1]!;
  const settings = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::settings::spot`,
    arguments: [
      tx.pure.u64(PERPSPLEXITY_CURVE_BASE_FEE_BPS),
      tx.pure.bool(PERPSPLEXITY_CURVE_HIBERNATION),
    ],
  });
  // The launch fee is paid in SUI off the gas coin; the 1 USDC pool seed is
  // split off the wallet's own USDC, exactly as the official launch form does.
  const [feeCoin] = tx.splitCoins(tx.gas, [tx.pure.u64(launchFeeMist)]);
  const primaryQuote = tx.objectRef({
    objectId: seedPrimary.coinObjectId,
    version: seedPrimary.version,
    digest: seedPrimary.digest,
  });
  if (BigInt(seedPrimary.balance) < PERPSPLEXITY_CURVE_SEED_UNITS && seedSource.length > 1) {
    tx.mergeCoins(
      primaryQuote,
      seedSource
        .slice(1)
        .map((coin) => tx.objectRef({ objectId: coin.coinObjectId, version: coin.version, digest: coin.digest })),
    );
  }
  const [seedCoin] = tx.splitCoins(primaryQuote, [tx.pure.u64(PERPSPLEXITY_CURVE_SEED_UNITS)]);
  const launchResults = tx.moveCall({
    target: `${PERPSPLEXITY_PACKAGE_ID}::launchpad::launch_registered`,
    typeArguments: [coinType, PERPSPLEXITY_CURVE_QUOTE_TYPE],
    arguments: [
      tx.sharedObjectRef({ ...launchpadRef, mutable: true }),
      tx.sharedObjectRef({ ...configRef, mutable: false }),
      treasuryCap,
      initializer,
      seedCoin!,
      feeCoin!,
      tx.pure.u64(PERPSPLEXITY_CURVE_SUPPLY),
      settings,
      tx.pure.u64(virtualQuote),
      tx.sharedObjectRef({ ...clockRef, mutable: false }),
    ],
  }) as TransactionArgument[];
  tx.transferObjects([launchResults[0]!, launchResults[1]!, launchResults[2]!], sender);

  const run = await signAndExecute(tx, keypair);
  if (!run.ok || !run.digest) {
    return fail(run.error ?? "The Perpsplexity curve launch failed.", { digest: run.digest, coinType, packageId });
  }
  const receipt = await fetchReceipt(run.digest);
  if (!receipt.ok) {
    return fail(receipt.error ?? "The Perpsplexity curve launch failed on chain.", {
      digest: run.digest,
      coinType,
      packageId,
    });
  }
  const created = receipt.events.find(
    (event) => event.type === `${PERPSPLEXITY_ORIGINAL_PACKAGE_ID}::pool::PoolCreated`,
  );
  const poolId = eventField(created, "pool");
  if (!poolId) {
    return fail("The launch finished without the pool's on-chain confirmation.", {
      digest: run.digest,
      coinType,
      packageId,
    });
  }

  // Step 3 — the creator's own first buy, when one was requested. The pool is
  // only shared by the launch call, so this is a follow-up transaction against
  // the confirmed pool: pool::buy<COIN, USDC>(pool, config, coin, min_out,
  // deadline_ms, clock) → Position, paid for by and kept by the creator's own
  // wallet. A failure here never invalidates the launch; the curve is live.
  let devBuyDigest: string | null = null;
  let devBuyError: string | null = devBuy.skip;
  const curveBuyer = devBuy.buyer;
  if (devBuy.units > 0n && curveBuyer) {
    const outcome = await buyOnCurve({
      keypair: curveBuyer.signer,
      sender: curveBuyer.address,
      coinType,
      poolId,
      amount: devBuy.units,
      gasPrice,
      freshGas: () => freshGasFor(curveBuyer.address),
    });
    devBuyDigest = outcome.digest;
    devBuyError = outcome.error;
  }

  return {
    status: "CONFIRMED",
    digest: run.digest,
    error: null,
    coinType,
    packageId,
    poolId,
    engineId: null,
    devBuyDigest,
    devBuyError,
  };
}
